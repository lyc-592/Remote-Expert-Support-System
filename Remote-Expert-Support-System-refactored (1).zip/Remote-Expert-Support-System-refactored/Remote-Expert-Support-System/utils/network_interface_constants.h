#ifndef NETWORK_INTERFACE_CONSTANTS_H
#define NETWORK_INTERFACE_CONSTANTS_H

// 网络接口测试常数
static const QString host = "127.0.0.1";
static const quint16 hostPort = 1234;

#endif // NETWORK_INTERFACE_CONSTANTS_H
