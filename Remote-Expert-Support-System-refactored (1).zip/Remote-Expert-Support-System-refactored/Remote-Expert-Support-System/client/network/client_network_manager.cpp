#include "client_network_manager.h"
#include "../../utils/funcs.h"
#include "../../utils/constants.h"
#include <QUuid>
#include <QDebug>

ClientNetworkManager::ClientNetworkManager(QObject *parent) : QObject(parent), requestIdCounter(0)
{
    tcpSocket = new QTcpSocket(this);
    connect(tcpSocket, &QTcpSocket::connected, this, &ClientNetworkManager::onConnected);
    connect(tcpSocket, &QTcpSocket::disconnected, this, &ClientNetworkManager::onDisconnected);
    connect(tcpSocket, QOverload<QAbstractSocket::SocketError>::of(&QTcpSocket::errorOccurred),
            this, &ClientNetworkManager::onErrorOccurred);
    connect(tcpSocket, &QTcpSocket::readyRead, this, &ClientNetworkManager::onReadyRead);
}

ClientNetworkManager::~ClientNetworkManager()
{
    disconnectFromServer();
    delete tcpSocket;
}

void ClientNetworkManager::connectToServer(const QString &host, quint16 port)
{
    tcpSocket->connectToHost(host, port);
}

void ClientNetworkManager::disconnectFromServer()
{
    if (tcpSocket->state() != QAbstractSocket::UnconnectedState) {
        tcpSocket->disconnectFromHost();
    }
}

bool ClientNetworkManager::isConnected() const
{
    return tcpSocket->state() == QAbstractSocket::ConnectedState;
}

void ClientNetworkManager::onConnected()
{
    qInfo() << "Connected to server";
    emit connected();
}

void ClientNetworkManager::onDisconnected()
{
    qInfo() << "Disconnected from server";
    emit disconnected();
}

void ClientNetworkManager::onErrorOccurred(QAbstractSocket::SocketError error)
{
    QString errorMsg = tcpSocket->errorString();
    qWarning() << "Socket error:" << errorMsg;
    emit errorMsg;
}

/* 下面存放放出请求的功能代码 */

/* 请求登陆 */
void ClientNetworkManager::loginRequest(const QString &username, const QString &password)
{
    if (!isConnected()) {
        emit errorOccurred("Not connected to server");
        return;
    }

    // 创建登录请求JSON
    QJsonObject request;
    request["type"] = "login";
    request["request_id"] = QString::number(++requestIdCounter);
    request["username"] = username;
    request["password"] = encryptPassword(password);

    // 注册回调函数处理响应
    pendingRequests[request["request_id"].toString()] = [this](const QJsonObject &response) {
        bool success = response["success"].toBool();
        QString message = response["message"].toString();
        emit loginResponseReceived(success, message);
    };

    // 发送请求
    QJsonDocument doc(request);
    tcpSocket->write(doc.toJson());
    tcpSocket->flush();

    qInfo() << "Login Request Sending...";
}

void ClientNetworkManager::registerRequest(const QString& username, const QString& password,
                                           const QString& contact, const UserType& usertype,
                                            const QString &expertSkill)
{
    if (!isConnected()) {
        emit errorOccurred("Not connected to server");
        return;
    }

    // 创建注册请求JSON
    QJsonObject request;
    request["type"] = "register";
    request["request_id"] = QString::number(++requestIdCounter);
    request["usertype"] = usertype;
    request["username"] = username;
    request["password"] = encryptPassword(password);
    request["contact"] = contact;
    request["skill"] = expertSkill;

    // 注册回调函数处理响应
    pendingRequests[request["request_id"].toString()] = [this](const QJsonObject &response) {
        bool success = response["success"].toBool();
        QString message = response["message"].toString();
        emit loginResponseReceived(success, message);
    };

    // 发送请求
    QJsonDocument doc(request);
    tcpSocket->write(doc.toJson());
    tcpSocket->flush();

    qInfo() << "Register Request Sending...";
}

void ClientNetworkManager::onReadyRead() {
    QByteArray data = tcpSocket->readAll();
    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (doc.isNull() || !doc.isObject()) {
        qWarning() << "Invalid JSON response from server";
        return;
    }

    QJsonObject response = doc.object();
    QString requestId = response["request_id"].toString();
    if (pendingRequests.contains(requestId)) {
        auto callback = pendingRequests.take(requestId);
        callback(response);
    } else {
        qWarning() << "Unknown request ID in response:" << requestId;
    }
}

void ClientNetworkManager::sendMessage(const QByteArray &message)
{
    if (this->tcpSocket->state() == QAbstractSocket::ConnectedState) {
        this->tcpSocket->write(message);
    }
}
