#include <QApplication>
#include <QTimer>
#include <QDebug>
#include "test/conference_test.h"

// int main(int argc, char *argv[])
// {
//     conferenceTest(argc, argv);
// }
