#ifndef DATABASE_MANAGER_H
#define DATABASE_MANAGER_H

#include <QDebug>
#include <QDateTime>



#include <QtSql/qsqldatabase.h>



class DatabaseManager {
public:
    // 单例模式
    static DatabaseManager& getInstance() {
        static DatabaseManager instance;
        return instance;
    }

    // 初始化数据库
    bool init(const QString& dbName = "industrial_support.db");

    // 关闭数据库连接
    void close();

    // 检查数据库连接状态
    bool isConnected() const;

    // 示例：插入用户
    bool insertUser(int userType, const QString& account, const QString& password,
                    const QString& contact, int factoryId = -1, const QString& expertSkill = "");

    // 示例：创建工单
    bool createWorkOrder(int contactId, int deviceId, const QString& fault);

private:
    QSqlDatabase db;

    // 私有构造函数，防止实例化
    DatabaseManager() = default;
    ~DatabaseManager() { close(); }

    // 禁止拷贝
    DatabaseManager(const DatabaseManager&) = delete;
    DatabaseManager& operator=(const DatabaseManager&) = delete;

    // 创建所有表结构
    bool createTables();

    // 创建用户表
    bool createUserTable();

    // 创建设备表
    bool createDeviceTable();

    // 创建设备信息表
    bool createDeviceDataTable();

    // 创建工单表
    bool createWorkOrderTable();

    // 创建历史工单表
    bool createHistoryOrderTable();

    // 创建现场记录表
    bool createRecordTable();

    // 创建联系人表
    bool createContactTable();
};

#endif // DATABASE_MANAGER_H
