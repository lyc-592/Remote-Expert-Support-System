#include "mainwindow.h"

#include <QCoreApplication>
#include <QSqlQuery>

    int main(int argc, char *argv[]) {
    QCoreApplication a(argc, argv);

    // 初始化数据库
    if (!DatabaseManager::getInstance().init()) {
        qCritical() << "数据库初始化失败，程序退出";
        return 1;
    }
    qInfo() << "数据库初始化成功";

    // 查询 user 表数据
    QSqlQuery query("SELECT * FROM user");
    while (query.next()) {
        int userId = query.value("user_id").toInt();
        int userType = query.value("user_type").toInt();
        QString account = query.value("user_account").toString();
        QString contact = query.value("user_contact").toString();

        qDebug() << "用户ID:" << userId
                 << "类型:" << (userType == 0 ? "工厂用户" : "专家用户")
                 << "账号:" << account
                 << "联系方式:" << contact;
    }

    // 这里可以添加更多操作示例：
    // 1. 添加设备
    // 2. 创建联系人关系
    // 3. 创建工单
    // 4. 记录设备数据等

    // 关闭数据库连接
    DatabaseManager::getInstance().close();
    return a.exec();
}
