#include "mainwindow.h"
#include <QSqlQuery>

#include <QSqlError>

bool DatabaseManager::init(const QString& dbName) {
    // 移除已存在的连接
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        db = QSqlDatabase::database("qt_sql_default_connection");
    } else {
        // 建立SQLite数据库连接
        db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName(dbName);
    }

    // 打开数据库
    if (!db.open()) {
        qCritical() << "数据库打开失败:" << db.lastError().text();
        return false;
    }

    // 启用外键约束
    QSqlQuery query;
    if (!query.exec("PRAGMA foreign_keys = ON;")) {
        qWarning() << "启用外键约束失败:" << query.lastError().text();
    }

    // 创建所有表
    return createTables();
}

void DatabaseManager::close() {
    if (db.isOpen()) {
        db.close();
    }
}

bool DatabaseManager::isConnected() const {
    return db.isOpen();
}

bool DatabaseManager::createTables() {
    return createUserTable() &&
           createDeviceTable() &&
           createDeviceDataTable() &&
           createContactTable() &&
           createWorkOrderTable() &&
           createHistoryOrderTable() &&
           createRecordTable();
}

bool DatabaseManager::createUserTable() {
    QSqlQuery query;
    QString sql = R"(
        CREATE TABLE IF NOT EXISTS user (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_type TINYINT NOT NULL CHECK (user_type IN (0, 1)),
            user_account TEXT NOT NULL UNIQUE,
            user_password TEXT NOT NULL,
            user_contact TEXT NOT NULL,
            factory_id INTEGER,
            expert_skill TEXT,
            -- 检查约束：工厂用户必须有factory_id，专家用户必须有expert_skill
            CHECK (
                (user_type = 0 AND factory_id IS NOT NULL) OR
                (user_type = 1 AND expert_skill IS NOT NULL)
            )
        )
    )";
    return query.exec(sql);
}

bool DatabaseManager::createDeviceTable() {
    QSqlQuery query;
    QString sql = R"(
        CREATE TABLE IF NOT EXISTS device (
            device_id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_name TEXT NOT NULL,
            device_type TEXT NOT NULL
        )
    )";
    return query.exec(sql);
}

bool DatabaseManager::createDeviceDataTable() {
    QSqlQuery query;
    QString sql = R"(
        CREATE TABLE IF NOT EXISTS device_data (
            info_id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER NOT NULL,
            temp REAL,
            pressure REAL,
            vibration REAL,
            current REAL,
            data_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (device_id) REFERENCES device(device_id) ON DELETE CASCADE
        )
    )";
    return query.exec(sql);
}

bool DatabaseManager::createContactTable() {
    QSqlQuery query;
    QString sql = R"(
        CREATE TABLE IF NOT EXISTS contact (
            contact_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user1_id INTEGER NOT NULL,
            user1_type TINYINT NOT NULL CHECK (user1_type IN (0, 1)),
            user2_id INTEGER NOT NULL,
            user2_type TINYINT NOT NULL CHECK (user2_type IN (0, 1)),
            contact_status TINYINT NOT NULL DEFAULT 0 CHECK (contact_status IN (0, 1, 2)),
            order_id INTEGER,
            create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            -- 确保是不同类型用户之间的联系
            CHECK (user1_type != user2_type),
            -- 确保用户ID有效
            FOREIGN KEY (user1_id) REFERENCES user(user_id) ON DELETE CASCADE,
            FOREIGN KEY (user2_id) REFERENCES user(user_id) ON DELETE CASCADE,
            FOREIGN KEY (order_id) REFERENCES workorder(order_id) ON DELETE SET NULL,
            -- 确保联系关系唯一
            UNIQUE(user1_id, user2_id)
        )
    )";
    return query.exec(sql);
}

bool DatabaseManager::createWorkOrderTable() {
    QSqlQuery query;
    QString sql = R"(
        CREATE TABLE IF NOT EXISTS workorder (
            order_id INTEGER PRIMARY KEY AUTOINCREMENT,
            contact_id INTEGER NOT NULL,
            device_id INTEGER NOT NULL,
            order_status TINYINT NOT NULL DEFAULT 0 CHECK (order_status IN (0, 1)),
            fault TEXT NOT NULL,
            create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (contact_id) REFERENCES contact(contact_id) ON DELETE CASCADE,
            FOREIGN KEY (device_id) REFERENCES device(device_id) ON DELETE CASCADE
        )
    )";
    return query.exec(sql);
}

bool DatabaseManager::createHistoryOrderTable() {
    QSqlQuery query;
    QString sql = R"(
        CREATE TABLE IF NOT EXISTS history_order (
            history_order_id INTEGER PRIMARY KEY AUTOINCREMENT,
            factory_user_id INTEGER NOT NULL,
            expert_user_id INTEGER NOT NULL,
            device_id INTEGER NOT NULL,
            order_id INTEGER NOT NULL,
            order_status TINYINT NOT NULL CHECK (order_status IN (0, 1)),
            order_create_time DATETIME NOT NULL,
            order_end_time DATETIME NOT NULL,
            FOREIGN KEY (factory_user_id) REFERENCES user(user_id) ON DELETE CASCADE,
            FOREIGN KEY (expert_user_id) REFERENCES user(user_id) ON DELETE CASCADE,
            FOREIGN KEY (device_id) REFERENCES device(device_id) ON DELETE CASCADE,
            FOREIGN KEY (order_id) REFERENCES workorder(order_id) ON DELETE CASCADE
        )
    )";
    return query.exec(sql);
}

bool DatabaseManager::createRecordTable() {
    QSqlQuery query;
    QString sql = R"(
        CREATE TABLE IF NOT EXISTS record (
            record_id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            video_path TEXT,
            file_path TEXT,
            device_status_data_path TEXT,
            fault_type TEXT,
            solution TEXT,
            upload_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES workorder(order_id) ON DELETE CASCADE
        )
    )";
    return query.exec(sql);
}

bool DatabaseManager::insertUser(int userType, const QString& account, const QString& password,
                                 const QString& contact, int factoryId, const QString& expertSkill) {
    if (!isConnected()) {
        qWarning() << "数据库未连接";
        return false;
    }

    QSqlQuery query;
    query.prepare(R"(
        INSERT INTO user (user_type, user_account, user_password, user_contact, factory_id, expert_skill)
        VALUES (:type, :account, :password, :contact, :factoryId, :skill)
    )");

    query.bindValue(":type", userType);
    query.bindValue(":account", account);
    query.bindValue(":password", password);  // 实际应用中应加密存储
    query.bindValue(":contact", contact);

    // 根据用户类型绑定专属字段
    if (userType == 0) {  // 工厂用户
        query.bindValue(":factoryId", factoryId);
        query.bindValue(":skill", QVariant(QVariant::String));
    } else {  // 专家用户
        query.bindValue(":factoryId", QVariant(QVariant::Int));
        query.bindValue(":skill", expertSkill);
    }

    if (!query.exec()) {
        qWarning() << "插入用户失败:" << query.lastError().text();
        return false;
    }
    return true;
}

bool DatabaseManager::createWorkOrder(int contactId, int deviceId, const QString& fault) {
    if (!isConnected()) {
        qWarning() << "数据库未连接";
        return false;
    }

    QSqlQuery query;
    query.prepare(R"(
        INSERT INTO workorder (contact_id, device_id, order_status, fault)
        VALUES (:contactId, :deviceId, 0, :fault)
    )");

    query.bindValue(":contactId", contactId);
    query.bindValue(":deviceId", deviceId);
    query.bindValue(":fault", fault);

    if (!query.exec()) {
        qWarning() << "创建工单失败:" << query.lastError().text();
        return false;
    }

    // 获取刚创建的工单ID并更新联系人表的最新工单ID
    int orderId = query.lastInsertId().toInt();
    query.prepare("UPDATE contact SET order_id = :orderId WHERE contact_id = :contactId");
    query.bindValue(":orderId", orderId);
    query.bindValue(":contactId", contactId);

    if (!query.exec()) {
        qWarning() << "更新联系人表工单ID失败:" << query.lastError().text();
        return false;
    }

    return true;
}
