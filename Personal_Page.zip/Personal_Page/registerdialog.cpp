#include "registerdialog.h"
#include <QFormLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QMessageBox>

RegisterDialog::RegisterDialog(QWidget *parent)
    : QDialog(parent)
{
    setupUI();
    setWindowTitle("用户注册");
    setFixedSize(380, 220);
}

void RegisterDialog::setupUI()
{
    mailEdit    = new QLineEdit;
    userEdit    = new QLineEdit;
    passEdit    = new QLineEdit;
    confirmEdit = new QLineEdit;
    passEdit->setEchoMode(QLineEdit::Password);
    confirmEdit->setEchoMode(QLineEdit::Password);

    regBtn    = new QPushButton("注册");
    cancelBtn = new QPushButton("取消");

    QFormLayout *form = new QFormLayout(this);
    form->addRow("邮  箱:", mailEdit);
    form->addRow("用户名:", userEdit);
    form->addRow("密  码:", passEdit);
    form->addRow("确认密码:", confirmEdit);

    QHBoxLayout *btnLay = new QHBoxLayout;
    btnLay->addStretch();
    btnLay->addWidget(regBtn);
    btnLay->addWidget(cancelBtn);
    form->addRow(btnLay);

    connect(regBtn,    &QPushButton::clicked, this, &RegisterDialog::onRegisterClicked);
    connect(cancelBtn, &QPushButton::clicked, this, &RegisterDialog::onCancelClicked);
}

void RegisterDialog::onRegisterClicked()
{
    if (passEdit->text() != confirmEdit->text()) {
        QMessageBox::warning(this, "错误", "两次密码输入不一致！");
        return;
    }

    QString user = userEdit->text().trimmed();
    QString pwd  = passEdit->text();

    emit registered(user, pwd);   // 发信号
    accept();                     // 关闭对话框
}

void RegisterDialog::onCancelClicked()
{
    reject();
}
