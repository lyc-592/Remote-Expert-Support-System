#ifndef REGISTERDIALOG_H
#define REGISTERDIALOG_H

#include <QMainWindow>
#include <QDialog>

QT_BEGIN_NAMESPACE
class QLineEdit;
class QPushButton;
QT_END_NAMESPACE

class RegisterDialog : public QDialog
{
    Q_OBJECT
public:
    explicit RegisterDialog(QWidget *parent = nullptr);

signals:
    void registered(const QString &user, const QString &pwd);   // 新增信号

private slots:
    void onRegisterClicked();
    void onCancelClicked();

private:
    void setupUI();

    QLineEdit *mailEdit;
    QLineEdit *userEdit;
    QLineEdit *passEdit;
    QLineEdit *confirmEdit;
    QPushButton *regBtn;
    QPushButton *cancelBtn;
};

#endif // REGISTERDIALOG_H
