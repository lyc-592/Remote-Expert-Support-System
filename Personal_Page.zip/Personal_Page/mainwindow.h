#ifndef MAINWINDOW_H
#define MAINWindow_H

#include <QMainWindow>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QCheckBox>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFile>
#include <QMessageBox>
#include <QScrollArea>  // 添加滚动区域头文件

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onLoginClicked();
    void onCancelClicked();
    void openRegisterDialog();
    void onUserRegistered(const QString &user, const QString &pwd);
    void openFindPasswordDialog();
    void onFindRequested(const QString &emailOrPhone);

private:
    void setupUI();
    void loadStyleSheet();

    // UI 组件
    QScrollArea *scrollArea;  // 滚动区域
    QWidget *scrollContent;   // 滚动内容容器
    QLabel *titleLabel;
    QLabel *userLabel;
    QLineEdit *userEdit;
    QLabel *passLabel;
    QLineEdit *passEdit;
    QCheckBox *rememberCheck;
    QCheckBox *autoLoginCheck;
    QPushButton *loginButton;
    QPushButton *cancelButton;
    QGroupBox *settingsGroup;
    QLabel      *registerLabel;
    QPushButton *registerButton;
    QPushButton *forgetButton;
};

#endif // MAINWINDOW_H
