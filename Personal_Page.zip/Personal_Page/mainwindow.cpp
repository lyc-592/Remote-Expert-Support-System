#include "mainwindow.h"
#include "registerdialog.h"
#include "findpassworddialog.h"
#include <QApplication>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QScrollArea>
#include <QGroupBox>
#include <QCheckBox>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QFile>
#include <QMessageBox>
#include <QDebug>
#include <QToolButton>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupUI();
    loadStyleSheet();

    setWindowTitle("Qt QSS 示例 - 用户登录");
    setMinimumSize(500, 400);
    resize(550, 650);
}

MainWindow::~MainWindow() = default;

void MainWindow::setupUI()
{
    /* ---------- 滚动区域 ---------- */
    scrollArea = new QScrollArea(this);
    scrollArea->setWidgetResizable(true);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);

    /* ---------- 居中容器 ---------- */
    QWidget *centerContainer = new QWidget;
    scrollArea->setWidget(centerContainer);

    QHBoxLayout *hLay = new QHBoxLayout(centerContainer);
    hLay->setContentsMargins(0, 0, 0, 0);

    QWidget *formContainer = new QWidget;
    formContainer->setMaximumWidth(600);
    formContainer->setMaximumHeight(900);
    hLay->addStretch();
    hLay->addWidget(formContainer);
    hLay->addStretch();

    /* ---------- 主垂直布局 ---------- */
    QVBoxLayout *mainLayout = new QVBoxLayout(formContainer);
    mainLayout->setSpacing(20);
    mainLayout->setContentsMargins(40, 40, 40, 40);

    /* ---------- 标题 ---------- */
    titleLabel = new QLabel("欢迎进入工业现场远程专家支持系统！");
    titleLabel->setObjectName("titleLabel");
    titleLabel->setMinimumHeight(80);
    titleLabel->setWordWrap(true);

    /* ---------- 表单控件 ---------- */
    userLabel = new QLabel("用户名:");
    userEdit  = new QLineEdit;
    userEdit->setPlaceholderText("请输入您的用户名");
    userEdit->setMinimumHeight(40);

    // passLabel = new QLabel("密码:");
    // passEdit  = new QLineEdit;
    // passEdit->setPlaceholderText("请输入您的密码");
    // passEdit->setEchoMode(QLineEdit::Password);
    // passEdit->setMinimumHeight(40);

    passLabel = new QLabel("密码:");

    // 创建密码输入框
    passEdit = new QLineEdit;
    passEdit->setPlaceholderText("请输入您的密码");
    passEdit->setEchoMode(QLineEdit::Password);
    passEdit->setMinimumHeight(40);

    // 创建忘记密码按钮并内嵌到密码框中
    QToolButton *forgetBtn = new QToolButton(passEdit);
    forgetBtn->setText("忘记密码?");
    forgetBtn->setObjectName("forgetInlineBtn");
    forgetBtn->setCursor(Qt::PointingHandCursor);
    forgetBtn->setStyleSheet("QToolButton { border: none; padding: 0 8px; color: #7B6DC2; background: transparent; }"
                             "QToolButton:hover { color: #5C4F9E; text-decoration: underline; }");

    // 使用布局将按钮放置在密码框右侧
    QHBoxLayout *passEditLayout = new QHBoxLayout(passEdit);
    passEditLayout->setContentsMargins(0, 0, 0, 0);
    passEditLayout->setSpacing(0);
    passEditLayout->addStretch(); // 将按钮推到最右边
    passEditLayout->addWidget(forgetBtn);

    /* ---------- 登录设置组 ---------- */
    settingsGroup = new QGroupBox("登录设置");
    settingsGroup->setObjectName("settingsGroup");
    settingsGroup->setMinimumHeight(100);

    rememberCheck = new QCheckBox("记住密码");
    autoLoginCheck = new QCheckBox("自动登录");

    QHBoxLayout *groupLay = new QHBoxLayout(settingsGroup);
    groupLay->addWidget(rememberCheck);
    groupLay->addWidget(autoLoginCheck);

    /* ---------- 按钮 ---------- */
    loginButton  = new QPushButton("登录");
    loginButton->setObjectName("loginButton");
    loginButton->setMinimumHeight(40);

    cancelButton = new QPushButton("取消");
    cancelButton->setObjectName("cancelButton");
    cancelButton->setMinimumHeight(40);

    QHBoxLayout *btnLay = new QHBoxLayout;
    //btnLay->addStretch();
    btnLay->addWidget(loginButton);
    btnLay->addWidget(cancelButton);

    /* ---------- “还没有账户？立即注册” ---------- */
    QWidget *regWidget = new QWidget;
    QHBoxLayout *regLay = new QHBoxLayout(regWidget);
    regLay->setContentsMargins(0, 0, 0, 0);

    registerLabel  = new QLabel("还没有账户？");
    registerLabel->setObjectName("registerLabel");

    registerButton = new QPushButton("立即注册");
    registerButton->setObjectName("registerButton");
    registerButton->setFlat(true);
    registerButton->setCursor(Qt::PointingHandCursor);

    regLay->addStretch();
    regLay->addWidget(registerLabel);
    regLay->addWidget(registerButton);
    regLay->addStretch();

    /* ---------- “忘记密码” ---------- */
    forgetButton = new QPushButton("忘记密码");
    forgetButton->setObjectName("forgetButton");
    forgetButton->setFlat(true);
    forgetButton->setCursor(Qt::PointingHandCursor);

    /* ---------- 组装 ---------- */
    mainLayout->addWidget(titleLabel);
    mainLayout->addWidget(userLabel);
    mainLayout->addWidget(userEdit);
    mainLayout->addWidget(passLabel);
    mainLayout->addWidget(passEdit);
    mainLayout->addWidget(settingsGroup);
    mainLayout->addStretch();
    mainLayout->addLayout(btnLay);
    mainLayout->addWidget(regWidget);

    setCentralWidget(scrollArea);

    /* ---------- 信号槽 ---------- */
    connect(loginButton,  &QPushButton::clicked, this, &MainWindow::onLoginClicked);
    connect(cancelButton, &QPushButton::clicked, this, &MainWindow::onCancelClicked);
    connect(registerButton, &QPushButton::clicked, this, &MainWindow::openRegisterDialog);
    connect(forgetBtn, &QToolButton::clicked, this, &MainWindow::openFindPasswordDialog);
}

void MainWindow::loadStyleSheet()
{
    QFile styleFile(":/qss/style1.qss");
    if (styleFile.open(QFile::ReadOnly | QFile::Text))
    {
        QString style = QLatin1String(styleFile.readAll());
        qApp->setStyleSheet(style);
        styleFile.close();
        qDebug() << "QSS 文件加载成功！";
    }
    else
    {
        QMessageBox::warning(this, "警告", "无法加载样式表文件！");
    }
}

void MainWindow::onLoginClicked()
{
    const QString user = userEdit->text().trimmed();
    const QString pass = passEdit->text().trimmed();

    if (user.isEmpty() || pass.isEmpty())
    {
        QMessageBox::warning(this, "输入错误", "用户名和密码不能为空！");
        return;
    }

    QMessageBox::information(this, "登录成功",
                             QString("欢迎 %1！\n登录设置：\n记住密码：%2\n自动登录：%3")
                                 .arg(user)
                                 .arg(rememberCheck->isChecked() ? "是" : "否")
                                 .arg(autoLoginCheck->isChecked() ? "是" : "否"));
}

void MainWindow::onCancelClicked()
{
    if (QMessageBox::question(this, "确认", "确定要退出吗？",
                              QMessageBox::Yes | QMessageBox::No)
        == QMessageBox::Yes)
    {
        qApp->quit();
    }
}

void MainWindow::openRegisterDialog()
{
    RegisterDialog dlg(this);
    connect(&dlg, &RegisterDialog::registered,
            this, &MainWindow::onUserRegistered);   // 接收注册信号
    dlg.exec();
}

void MainWindow::onUserRegistered(const QString &user, const QString &pwd)
{
    // 自动把用户名填回登录框，密码框留空让用户再输入
    userEdit->setText(user);
    passEdit->clear();
    passEdit->setFocus();
}

void MainWindow::openFindPasswordDialog()
{
    FindPasswordDialog dlg(this);
    connect(&dlg, &FindPasswordDialog::findRequested,
            this, &MainWindow::onFindRequested);
    dlg.exec();
}

void MainWindow::onFindRequested(const QString &emailOrPhone)
{
    QMessageBox::information(this, "找回提示",
                             QString("已向 %1 发送找回邮件，请查收！").arg(emailOrPhone));
    /* 此处可扩展：调用后台接口等 */
}
